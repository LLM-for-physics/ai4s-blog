import torch
import torch.nn as nn
from torch.utils.tensorboard.writer import SummaryWriter
import numpy as np
import os
import tqdm

# 定义 PINN（物理信息神经网络）类，用于解决泊松方程问题
class PINN(nn.Module):
    """
    物理信息神经网络 (Physics-Informed Neural Network, PINN)
    
    输入：三维坐标 (x, y, z)
    输出：标量场值 u

    参数：
        hidden_dim (int): 隐藏层的数量
        layer_width (int): 每个隐藏层的神经元数量
        device (str): 运行设备（如 'cuda' 或 'cpu'）
    """
    def __init__(self, hidden_dim=5, layer_width=128, device=None):
        super(PINN, self).__init__()
        self.hidden_dim = hidden_dim
        self.layer_width = layer_width
        self.layer_widths = [3,] + [layer_width] * hidden_dim + [1,]  # 定义网络层结构
        layers_list = []
        for i in range(len(self.layer_widths) - 1):
            layers_list.append(nn.Linear(self.layer_widths[i], self.layer_widths[i + 1]))
            layers_list.append(nn.Tanh())  # 使用 Tanh 激活函数
        layers_list.pop()  # 移除最后一层的激活函数
        self.layers = nn.Sequential(*layers_list)
        if device is None:
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        else:
            self.device = torch.device(device)
        self.to(self.device)
        
    def forward(self, r):
        """
        前向传播函数

        参数：
            r (torch.Tensor): 输入的三维坐标 (x, y, z)
        返回：
            torch.Tensor: 标量场值 u
        """
        return self.layers(r)


# 定义损失函数类，用于计算 PDE 和边界条件的损失
class Loss:
    """
    损失函数类，用于评估物理信息神经网络的性能

    参数：
        model (PINN): 神经网络模型
        n_boundary (int): 用于计算边界条件损失的点的数量
        n_source (int): 用于计算PDE损失的点的数量
        seed (int): 随机种子
    """
    def __init__(self, model, n_boundary=1_000, n_source=10_000, seed=None):
        self.model = model
        self.n_boundary = n_boundary
        self.n_source = n_source
        self.np_rng = np.random.Generator(np.random.MT19937(seed))
        torch.random.manual_seed(self.np_rng.integers(-0x8000_0000_0000_0000, 0x7fff_ffff_ffff_ffff))
        self.seed = self.np_rng.bit_generator.seed_seq

        # 边界点的附加矩阵：边界维度上为正负1，剩余两个维度为0。此矩阵用于快速生成边界点坐标。
        self.boundary_additional_mat = torch.zeros((6 * self.n_boundary, 3))
        self.boundary_additional_mat[:self.n_boundary, 0] = 1
        self.boundary_additional_mat[self.n_boundary:2 * self.n_boundary, 0] = -1
        self.boundary_additional_mat[2 * self.n_boundary:3 * self.n_boundary, 1] = 1
        self.boundary_additional_mat[3 * self.n_boundary:4 * self.n_boundary, 1] = -1
        self.boundary_additional_mat[4 * self.n_boundary:5 * self.n_boundary, 2] = 1
        self.boundary_additional_mat[5 * self.n_boundary:6 * self.n_boundary, 2] = -1

        # 初始化边界点的附加矩阵和空心矩阵：界维度上为0，剩余两个维度为1。此矩阵用于快速生成边界点坐标。
        self.boundary_hollow_mat = torch.where(self.boundary_additional_mat != 0.0, 0.0, 1.0)
        self.boundary_additional_mat = self.boundary_additional_mat.type(torch.float32).to(self.model.device)
        self.boundary_hollow_mat = self.boundary_hollow_mat.type(torch.float32).to(self.model.device)

        # 常量100：位于GPU上，效果未知
        self._a_hundred = torch.tensor(100, dtype=torch.float32, device=self.model.device)

    def source_term(self, r):
        """
        泊松方程的源项 f(x, y, z)

        参数：
            r (torch.Tensor): 输入的三维坐标 (x, y, z)
        返回：
            torch.Tensor: 源项值
        """
        return self._a_hundred * r[..., 0] * r[..., 1] * r[..., 2]**2
    
    def pde_loss(self, r):
        """
        计算 PDE 残差的均方误差 (MSE) 损失

        参数：
            r (torch.Tensor): 输入的三维坐标 (x, y, z)
        返回：
            torch.Tensor: PDE 损失值
        """
        r.requires_grad_()
        u = self.model(r)
        
        # 计算一阶导数
        du = torch.autograd.grad(
            u, 
            r, 
            grad_outputs=torch.ones_like(u),
            create_graph=True, 
            retain_graph=True
        )[0]
        
        # 计算二阶导数
        u_xx = torch.autograd.grad(
            du[..., 0].unsqueeze(-1), 
            r, 
            grad_outputs=torch.ones_like(u),
            create_graph=True
        )[0][..., 0]
        u_yy = torch.autograd.grad(
            du[..., 1].unsqueeze(-1), 
            r, 
            grad_outputs=torch.ones_like(u),
            create_graph=True
        )[0][..., 1]
        u_zz = torch.autograd.grad(
            du[..., 2].unsqueeze(-1), 
            r, 
            grad_outputs=torch.ones_like(u),
            create_graph=True
        )[0][..., 2]
        
        # 泊松方程：∇²u = f
        f = self.source_term(r)
        pde_residual = u_xx + u_yy + u_zz + f
        
        return torch.mean(pde_residual**2)
    
    def boundary_loss(self, r):
        """
        计算边界条件的损失（零边界条件）

        参数：
            r (torch.Tensor): 边界点的三维坐标
        返回：
            torch.Tensor: 边界损失值
        """
        return torch.mean((self.model(r))**2)
    
    def __call__(self):
        """
        计算总损失，包括 PDE 损失和边界损失

        返回：
            tuple: (PDE 损失, 边界损失)
        """
        source_points = (torch.rand((self.n_source, 3), dtype=torch.float32, device=self.model.device) * 2 - 1)
        boundary_points = (torch.rand((self.n_boundary * 6, 3), dtype=torch.float32, device=self.model.device) * 2 - 1)
        boundary_points = boundary_points * self.boundary_hollow_mat + self.boundary_additional_mat

        pde_loss = self.pde_loss(source_points)
        boundary_loss = self.boundary_loss(boundary_points)

        return pde_loss, boundary_loss

def train(model, n_epochs, lr=0.001, beta=1.0, seed=None, log_dir='./results/log/', save_dir='./results/checkpoints/', use_tqdm=True, tqdm_position=None):
    """
    训练物理信息神经网络模型

    参数：
        model (PINN): 待训练的神经网络模型
        n_epochs (int): 训练的总轮数
        lr (float): 学习率
        beta (float): 边界损失的权重系数
        seed (int): 随机种子
        log_dir (str): 日志保存路径
        save_dir (str): 模型保存路径
        use_tqdm (bool): 是否显示进度条
        tqdm_position (int): 进度条的位置
    """
    os.makedirs(log_dir, exist_ok=True)
    os.makedirs(save_dir, exist_ok=True)
    beta = torch.tensor(beta, dtype=torch.float32, device=model.device)
    loss_func = Loss(model, seed=seed)
    optimizer = torch.optim.Adam(model.parameters(), lr=lr)
    writer = SummaryWriter(log_dir=log_dir)
    loss_lowest = 1
    if use_tqdm:
        pbar = tqdm.tqdm(total=n_epochs, position=tqdm_position, leave=(tqdm_position is None)).__enter__()
    for epoch in range(n_epochs):
        optimizer.zero_grad()
        loss_pde, loss_bc = loss_func()

        writer.add_scalar(f'model_h={model.hidden_dim}_w={model.layer_width}_b={beta}_s={seed}/loss_pde', loss_pde.item(), epoch)
        writer.add_scalar(f'model_h={model.hidden_dim}_w={model.layer_width}_b={beta}_s={seed}/loss_bc', loss_bc.item(), epoch)

        loss = loss_pde + beta * loss_bc

        if loss.item() < loss_lowest:
            loss_lowest = loss.item()
            torch.save(model, os.path.join(save_dir, f'model_h={model.hidden_dim}_w={model.layer_width}_b={beta}_s={seed}_best.pth'))
        
        loss.backward()
        optimizer.step()
        
        if use_tqdm:
            pbar.set_postfix(epoch=epoch + 1, loss=loss.item())
            pbar.update()

    # 记录最后一轮训练结束后的损失
    epoch+=1
    loss_pde, loss_bc = loss_func()
    writer.add_scalar(f'model_h={model.hidden_dim}_w={model.layer_width}_b={beta}_s={seed}/loss_pde', loss_pde.item(), epoch)
    writer.add_scalar(f'model_h={model.hidden_dim}_w={model.layer_width}_b={beta}_s={seed}/loss_bc', loss_bc.item(), epoch)
    loss = loss_pde + beta * loss_bc
    if loss.item() < loss_lowest:
        loss_lowest = loss.item()
        torch.save(model, os.path.join(save_dir, f'model_h={model.hidden_dim}_w={model.layer_width}_b={beta}_s={seed}_best.pth'))
        
    if use_tqdm:
        pbar.__exit__(None, None, None)
    torch.save(model, os.path.join(save_dir, f'model_h={model.hidden_dim}_w={model.layer_width}_b={beta}_s={seed}_epoch_{n_epochs}.pth'))


def evaluate(model, points):
    """
    评估模型在给定点上的输出值

    参数：
        model (PINN): 神经网络模型
        points (list or np.ndarray): 三维空间中的点列表
    返回：
        np.ndarray: 模型在这些点上的输出值
    """
    points = torch.tensor(np.array(points, dtype=np.float32), dtype=torch.float32, device=model.device)
    with torch.no_grad():
        result = model(points)
    result = result.cpu().numpy().squeeze(-1)
    return result


def load(fn, load_dir='./results/checkpoints/'):
    """
    加载已保存的模型

    参数：
        fn (str): 模型文件名
        load_dir (str): 模型保存路径
    返回：
        PINN: 加载的神经网络模型
    """
    model = torch.load(os.path.join(load_dir, fn), weights_only=False)
    if model.device.type == 'cuda':
        model.device = torch.device('cuda')
    model.to(model.device)
    return model


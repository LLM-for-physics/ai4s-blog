# 给出目标问题的严格解（截断的级数展开）。
import numpy as np
from itertools import product

def phi(r, tr=100, use_tqdm=False):
    """
    使用截断的级数展开计算原泊松方程问题的严格解

    参数：
        r (np.ndarray): 输入的三维坐标 (x, y, z)
        tr (int): 级数截断位置
        use_tqdm (bool): 是否显示计算进度，默认为False
    返回：
        np.ndarray: 目标位置势函数的值 phi(x, y, z)
    """
    s=np.zeros(r.shape[:-1])
    if use_tqdm:
        from tqdm import tqdm
        pbar=tqdm(total=len(range(2,tr,2))**2*len(range(1,tr,2)))
    for l,m,n in product(range(2,tr,2), range(2,tr,2),range(1,tr,2)):
        s+=(
            (1-8/(n*np.pi)**2)/(l*m*n*(l**2+m**2+n**2))
            *np.sin(l*np.pi*(r[...,0]+1)/2)
            *np.sin(m*np.pi*(r[...,1]+1)/2)
            *np.sin(n*np.pi*(r[...,2]+1)/2)
        )
        if use_tqdm:
            pbar.update()
    return 25600/np.pi**5*s

def laplacian_3d_finite_difference(grid, dx=1.0, dy=1.0, dz=1.0):
    """
    使用有限差分法计算三维网格的Laplace算子
    
    参数:
        grid: 三维numpy数组，表示场值
        dx, dy, dz: 三个方向的网格间距
    
    返回:
        laplacian: 三维numpy数组，Laplace算子值
    """
    laplacian = np.zeros_like(grid)
    laplacian[1:-1, 1:-1, 1:-1] += (grid[2:, 1:-1, 1:-1] - 2 * grid[1:-1, 1:-1, 1:-1] + grid[:-2, 1:-1, 1:-1]) / (dx**2)
    laplacian[1:-1, 1:-1, 1:-1] += (grid[1:-1, 2:, 1:-1] - 2 * grid[1:-1, 1:-1, 1:-1] + grid[1:-1, :-2, 1:-1]) / (dy**2)
    laplacian[1:-1, 1:-1, 1:-1] += (grid[1:-1, 1:-1, 2:] - 2 * grid[1:-1, 1:-1, 1:-1] + grid[1:-1, 1:-1, :-2]) / (dz**2)
    return laplacian

if __name__=="__main__":
    # 初始化格点
    d=100
    xArr, yArr, zArr=np.meshgrid(
        np.linspace(-1, 1, d), 
        np.linspace(-1, 1, d), 
        np.linspace(-1, 1, d)
    )
    rArr=np.stack([xArr, yArr, zArr]).transpose(1, 2, 3, 0)

    # 计算格点处函数的值
    import time
    _start_time=time.time()
    oArr=phi(rArr, use_tqdm=True)
    _end_time=time.time()

    # 打印计算信息并存储计算结果
    print(_end_time-_start_time)
    print(rArr.shape, oArr.shape)
    np.savez("./results/strict_solution_data.npz", r=rArr, o=oArr)

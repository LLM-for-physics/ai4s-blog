import torch
import numpy as np
from pinn_class import PINN, train
import torch.multiprocessing as mp

def _task(args, worker_index):
    h, w, b, seed=args
    model=PINN(h, w, "cuda")
    n_epoch=100_000
    train(model, n_epochs=n_epoch, beta=b, seed=seed, tqdm_position=worker_index)

def train_worker(rank, world_size, arg_sublist):
    torch.cuda.init()
    cuda_count=torch.cuda.device_count()
    torch.cuda.set_device(rank%cuda_count)
    start_idx = rank * len(arg_sublist) // world_size
    end_idx = (rank + 1) * len(arg_sublist) // world_size
    local_args = arg_sublist[start_idx:end_idx]
    for arg in local_args:
        _task(arg, rank)

def main_1():
    import warnings, os
    warnings.filterwarnings('ignore')
    argList=[]
    for h in [2, 3, 4, 5, 6, 7, 8, 9]:
        for seed in [12, 23, 34, 45]:
            argList.append((h, 128, 1.0, seed))
            argList.append((h, 512, 1.0, seed))
    for w in [32, 64, 128, 192, 256, 384, 512, 768]:
        for seed in [12, 23, 34, 45]:
            argList.append((5, w, 1.0, seed))
    for b in [0.001, 0.01, 0.1, 1, 10, 100, 1000]:
        for seed in [12, 23, 34, 45]:
            argList.append((5, 128, b, seed))
    argList=list(set(argList))
    np.random.shuffle(argList)

    cuda_count=torch.cuda.device_count()
    
    mp.spawn(train_worker,
             args=(cuda_count, argList),
             nprocs=cuda_count,
             join=True)
    

def main_2():
    # 更加细化地寻找最佳参数
    import warnings, os
    warnings.filterwarnings('ignore')
    argList=[]
    for w in range(448, 768, 64):
        for seed in [123, 234, 345, 456]:
            argList.append((3, w, 1000, seed))
    for w in range(224, 384, 32):
        for seed in [123, 234, 345, 456]:
            argList.append((4, w, 1000, seed))
    for w in range(112, 192, 16):
        for seed in [123, 234, 345, 456]:
            argList.append((5, w, 1000, seed))
    for w in range(64, 128+1, 8):
        for seed in [123, 234, 345, 456]:
            argList.append((6, w, 1000, seed))
    for w in range(64, 128+1, 8):
        for seed in [123, 234, 345, 456]:
            argList.append((7, w, 1000, seed))
    for b in [1e3, 1e4, 1e5, 1e6, 1e7]:
        for seed in [123, 234, 345, 456]:
            argList.append((5, 128, b, seed))
    for b in [1e3, 1e4, 1e5, 1e6, 1e7]:
        for seed in [123, 234, 345, 456]:
            argList.append((3, 512, b, seed))
    for b in [1e2, 1e3, 1e4, 1e5, 1e6]:
        for seed in [123, 234, 345, 456]:
            argList.append((6, 80, b, seed))
    argList=list(set(argList))
    np.random.shuffle(argList)

    cuda_count=torch.cuda.device_count()
    
    mp.spawn(train_worker,
             args=(cuda_count, argList),
             nprocs=cuda_count,
             join=True)
    
def main_3():
    # 根据以上得到的结果优化参数进行更进一步的训练
    import warnings
    warnings.filterwarnings('ignore')
    argList=[]
    for seed in [114, 514, 1919, 810, 137, 139, 149, 151, 157, 163]:
        argList.append((5, 128, 2000, seed))
    for seed in [114, 514, 1919, 810, 137, 139, 149, 151, 157, 163]:
        argList.append((3, 448, 10000, seed))
    cuda_count=torch.cuda.device_count()
    mp.spawn(train_worker,
             args=(cuda_count, argList),
             nprocs=cuda_count,
             join=True)
    

if __name__=="__main__":
    main_3()


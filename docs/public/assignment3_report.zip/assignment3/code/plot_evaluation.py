# 评估一个网格，绘制图像。

import numpy as np
import matplotlib.pyplot as plt
import os

def plot_ternary_function_advanced(
        func, z_planes=[-0.5, 0.2, 0.8], y_planes=[-0.5, 0.2, 0.8], 
        resolution=200, cmap='viridis', figsize=(16, 10), 
        save_dir='./results/fig/', save_filename='fig.png'):
    """
    增强版的三元函数二维切片绘制
    
    参数:
    func: 三元函数
    z_planes, y_planes: 切片平面位置
    resolution: 分辨率
    cmap: 颜色映射
    figsize: 图形大小
    """
    
    coord = np.linspace(-1, 1, resolution)
    X, Y = np.meshgrid(coord, coord, indexing='ij')
    
    # 预计算全局值范围
    test_samples = []
    for z in z_planes:
        points = np.stack([X, Y, np.full_like(X, z)], axis=-1)
        test_samples.append(func(points))
    for y in y_planes:
        points = np.stack([X, np.full_like(X, y), Y], axis=-1)
        test_samples.append(func(points))
    
    all_values = np.concatenate([arr.flatten() for arr in test_samples])
    vmin, vmax = np.min(all_values), np.max(all_values)
    
    # 创建图形
    fig, axes = plt.subplots(2, 3, figsize=figsize)
    
    # 绘制XY平面切片
    for idx, z_val in enumerate(z_planes):
        ax = axes[0, idx]
        points = np.stack([X, Y, np.full_like(X, z_val)], axis=-1)
        values = func(points)
        
        im = ax.contourf(X, Y, values, levels=50, cmap=cmap, vmin=vmin, vmax=vmax)
        ax.set_title(f'XY-plane @ z = {z_val}', fontsize=12, fontweight='bold')
        ax.set_xlabel('x')
        ax.set_ylabel('y')
        ax.set_aspect('equal')
        
        # 添加等高线
        ax.contour(X, Y, values, levels=10, colors='white', alpha=0.3, linewidths=0.5)
    
    # 绘制XZ平面切片
    for idx, y_val in enumerate(y_planes):
        ax = axes[1, idx]
        points = np.stack([X, np.full_like(X, y_val), Y], axis=-1)
        values = func(points)
        
        im = ax.contourf(X, Y, values, levels=50, cmap=cmap, vmin=vmin, vmax=vmax)
        ax.set_title(f'XZ-plane @ y = {y_val}', fontsize=12, fontweight='bold')
        ax.set_xlabel('x')
        ax.set_ylabel('z')
        ax.set_aspect('equal')
        
        # 添加等高线
        ax.contour(X, Y, values, levels=10, colors='white', alpha=0.3, linewidths=0.5)
    
    # 添加颜色条
    plt.tight_layout()
    fig.subplots_adjust(right=0.9)
    cbar_ax = fig.add_axes([0.92, 0.15, 0.02, 0.7])
    fig.colorbar(im, cax=cbar_ax, label='function value')

    plt.savefig(os.path.join(save_dir, save_filename))
    plt.close(fig)


if __name__ == "__main__":
    from pinn_class import evaluate, load
    for fp in os.listdir('./results/checkpoints/'):
        if fp.endswith('_best.pth'):
            model=load(fp)
            plot_ternary_function_advanced(lambda r:evaluate(model, r), save_filename=f'fig_{fp[6:-4]}.png')
            print(fp)
            del model
    from strict_solution import phi as phi_truncated
    plot_ternary_function_advanced(phi_truncated, save_filename='fig_truncated.png')
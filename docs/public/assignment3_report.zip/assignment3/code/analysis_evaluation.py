"""
读取loss_result.json并分析loss随着超参数h, w, b的变化趋势，以找到最佳参数。
为了获得loss_result.json文件，你需要运行loss_evaluation.py。
"""

import json
import matplotlib.pyplot as plt
from math import isclose, sqrt

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

with open('./results/loss_result.json') as file:
    raw_data=json.load(file)

def main1():
    hList=[]
    pdeList=[]
    bcList=[]
    mseList=[]
    for d in raw_data:
        if d['info']['w']==128 and isclose(d['info']['b'], 1.0):
            hList.append(d['info']['h'])
            pdeList.append(d['pde'])
            bcList.append(d['bc'])
            mseList.append(d['mse'])
    plt.scatter(hList, pdeList, marker='x', label='pde loss')
    plt.scatter(hList, bcList, marker='x', label='boundary loss')
    plt.scatter(hList, mseList, marker='x', label='absolute loss')
    plt.xlabel('depth')
    plt.ylabel('Delta')
    plt.yscale('log')
    plt.title('Loss-h plot @ w=128,b=1')
    plt.legend()
    plt.tight_layout()
    plt.savefig('./results/fig/fig_analysis_01.png')
    plt.close()

    hList=[]
    pdeList=[]
    bcList=[]
    mseList=[]
    for d in raw_data:
        if d['info']['w']==512 and isclose(d['info']['b'], 1.0):
            hList.append(d['info']['h'])
            pdeList.append(d['pde'])
            bcList.append(d['bc'])
            mseList.append(d['mse'])
    plt.scatter(hList, pdeList, marker='x', label='pde loss')
    plt.scatter(hList, bcList, marker='x', label='boundary loss')
    plt.scatter(hList, mseList, marker='x', label='absolute loss')
    plt.xlabel('depth')
    plt.ylabel('Delta')
    plt.yscale('log')
    plt.title('Loss-h plot @ w=512,b=1')
    plt.legend()
    plt.tight_layout()
    plt.savefig('./results/fig/fig_analysis_02.png')
    plt.close()

    wList=[]
    pdeList=[]
    bcList=[]
    mseList=[]
    for d in raw_data:
        if d['info']['h']==5 and isclose(d['info']['b'], 1.0):
            wList.append(d['info']['w'])
            pdeList.append(d['pde'])
            bcList.append(d['bc'])
            mseList.append(d['mse'])
    plt.scatter(wList, pdeList, marker='x', label='pde loss')
    plt.scatter(wList, bcList, marker='x', label='boundary loss')
    plt.scatter(wList, mseList, marker='x', label='absolute loss')
    plt.xlabel('width')
    plt.ylabel('Delta')
    plt.yscale('log')
    plt.title('Loss-w plot @ h=5,b=1')
    plt.legend()
    plt.tight_layout()
    plt.savefig('./results/fig/fig_analysis_03.png')
    plt.close()

    bList=[]
    pdeList=[]
    bcList=[]
    mseList=[]
    for d in raw_data:
        if d['info']['h']==5 and d['info']['w']==128:
            bList.append(d['info']['b'])
            pdeList.append(d['pde'])
            bcList.append(d['bc'])
            mseList.append(d['mse'])
    plt.scatter(bList, pdeList, marker='x', label='pde loss')
    plt.scatter(bList, bcList, marker='x', label='boundary loss')
    plt.scatter(bList, mseList, marker='x', label='absolute loss')
    plt.xlabel('beta')
    plt.ylabel('Delta')
    plt.xscale('log')
    plt.yscale('log')
    plt.title('Loss-b plot @ h=5,w=128')
    plt.legend()
    plt.tight_layout()
    plt.savefig('./results/fig/fig_analysis_04.png')
    plt.close()

def main2():
    xList=[]
    pdeList=[]
    bcList=[]
    mseList=[]
    for d in raw_data:
        if d['info']['h']==3 and isclose(d['info']['b'], 1000):
            xList.append(d['info']['w'])
            pdeList.append(d['pde'])
            bcList.append(d['bc'])
            mseList.append(d['mse'])
    plt.scatter(xList, pdeList, marker='x', label='pde loss')
    plt.scatter(xList, bcList, marker='x', label='boundary loss')
    plt.scatter(xList, mseList, marker='x', label='absolute loss')
    plt.xlabel('width')
    plt.ylabel('Delta')
    plt.yscale('log')
    plt.title('Loss-h plot @ h=3,b=1000')
    plt.legend()
    plt.tight_layout()
    plt.savefig('./results/fig/fig_analysis_05.png')
    plt.close()

    xList=[]
    pdeList=[]
    bcList=[]
    mseList=[]
    for d in raw_data:
        if d['info']['h']==4 and isclose(d['info']['b'], 1000):
            xList.append(d['info']['w'])
            pdeList.append(d['pde'])
            bcList.append(d['bc'])
            mseList.append(d['mse'])
    plt.scatter(xList, pdeList, marker='x', label='pde loss')
    plt.scatter(xList, bcList, marker='x', label='boundary loss')
    plt.scatter(xList, mseList, marker='x', label='absolute loss')
    plt.xlabel('width')
    plt.ylabel('Delta')
    plt.yscale('log')
    plt.title('Loss-h plot @ h=4,b=1000')
    plt.legend()
    plt.tight_layout()
    plt.savefig('./results/fig/fig_analysis_06.png')
    plt.close()

    xList=[]
    pdeList=[]
    bcList=[]
    mseList=[]
    for d in raw_data:
        if d['info']['h']==5 and isclose(d['info']['b'], 1000):
            xList.append(d['info']['w'])
            pdeList.append(d['pde'])
            bcList.append(d['bc'])
            mseList.append(d['mse'])
    plt.scatter(xList, pdeList, marker='x', label='pde loss')
    plt.scatter(xList, bcList, marker='x', label='boundary loss')
    plt.scatter(xList, mseList, marker='x', label='absolute loss')
    plt.xlabel('width')
    plt.ylabel('Delta')
    plt.yscale('log')
    plt.title('Loss-h plot @ h=5,b=1000')
    plt.legend()
    plt.tight_layout()
    plt.savefig('./results/fig/fig_analysis_07.png')
    plt.close()

    xList=[]
    pdeList=[]
    bcList=[]
    mseList=[]
    for d in raw_data:
        if d['info']['h']==6 and isclose(d['info']['b'], 1000):
            xList.append(d['info']['w'])
            pdeList.append(d['pde'])
            bcList.append(d['bc'])
            mseList.append(d['mse'])
    plt.scatter(xList, pdeList, marker='x', label='pde loss')
    plt.scatter(xList, bcList, marker='x', label='boundary loss')
    plt.scatter(xList, mseList, marker='x', label='absolute loss')
    plt.xlabel('width')
    plt.ylabel('Delta')
    plt.yscale('log')
    plt.title('Loss-h plot @ h=6,b=1000')
    plt.legend()
    plt.tight_layout()
    plt.savefig('./results/fig/fig_analysis_08.png')
    plt.close()

    bList=[]
    pdeList=[]
    bcList=[]
    mseList=[]
    for d in raw_data:
        if d['info']['h']==3 and d['info']['w']==512:
            bList.append(d['info']['b'])
            pdeList.append(d['pde'])
            bcList.append(d['bc'])
            mseList.append(d['mse'])
    plt.scatter(bList, pdeList, marker='x', label='pde loss')
    plt.scatter(bList, bcList, marker='x', label='boundary loss')
    plt.scatter(bList, mseList, marker='x', label='absolute loss')
    plt.xlabel('b')
    plt.ylabel('Delta')
    plt.xscale('log')
    plt.yscale('log')
    plt.title('Loss-b plot @ h=3,w=512')
    plt.legend()
    plt.tight_layout()
    plt.savefig('./results/fig/fig_analysis_09.png')
    plt.close()

def main3():
    print("Data with least PDE: ")
    print(*sorted(raw_data, key=lambda d:d['pde'])[:5], sep='\n')
    print()

    print("Data with least boundary loss: ")
    print(*sorted(raw_data, key=lambda d:d['bc'])[:5], sep='\n')
    print()

    print("Data with best precision: ")
    print(*sorted(raw_data, key=lambda d:d['mse'])[:5], sep='\n')
    print()


if __name__=="__main__":
    main1()
    main2()
    # main3()
    """\
Data with least PDE: 
{'info': {'h': 5, 'w': 128, 'b': 0.10000000149011612, 's': 12}, 'pde': 0.0009403475560247898, 'bc': 0.0626150444149971, 'mse': 0.002449324861039319}
{'info': {'h': 5, 'w': 128, 'b': 0.10000000149011612, 's': 45}, 'pde': 0.0012369481846690178, 'bc': 0.06033126637339592, 'mse': 0.0017011577432663307}
{'info': {'h': 5, 'w': 128, 'b': 1.0, 's': 23}, 'pde': 0.0013226703740656376, 'bc': 0.05112998187541962, 'mse': 0.00011594426722963301}
{'info': {'h': 6, 'w': 128, 'b': 1.0, 's': 45}, 'pde': 0.0014080191031098366, 'bc': 0.05119568482041359, 'mse': 0.00012837020055446005}
{'info': {'h': 5, 'w': 128, 'b': 1.0, 's': 34}, 'pde': 0.0014088940806686878, 'bc': 0.05090576410293579, 'mse': 8.169547288629373e-05}

Data with least boundary loss: 
{'info': {'h': 3, 'w': 512, 'b': 100000.0, 's': 234}, 'pde': 3.997079372406006, 'bc': 0.04756613448262215, 'mse': 4.8070002858637195e-05}
{'info': {'h': 5, 'w': 128, 'b': 100000.0, 's': 123}, 'pde': 1.503780484199524, 'bc': 0.04873685911297798, 'mse': 1.0876929275542149e-05}
{'info': {'h': 3, 'w': 512, 'b': 100000.0, 's': 456}, 'pde': 2.438062906265259, 'bc': 0.048794567584991455, 'mse': 8.56812293593914e-06}
{'info': {'h': 5, 'w': 128, 'b': 100000.0, 's': 345}, 'pde': 1.6700537204742432, 'bc': 0.048910751938819885, 'mse': 5.73889788260744e-06}
{'info': {'h': 3, 'w': 512, 'b': 100000.0, 's': 123}, 'pde': 2.525007963180542, 'bc': 0.04894300922751427, 'mse': 1.2314875301558374e-05}

Data with best precision: 
{'info': {'h': 6, 'w': 124, 'b': 1000.0, 's': 234}, 'pde': 0.01848851889371872, 'bc': 0.04973394796252251, 'mse': 1.5614419661172208e-07}
{'info': {'h': 6, 'w': 100, 'b': 1000.0, 's': 123}, 'pde': 0.013213496655225754, 'bc': 0.049785058945417404, 'mse': 1.629755388801485e-07}
{'info': {'h': 6, 'w': 112, 'b': 1000.0, 's': 456}, 'pde': 0.009889368899166584, 'bc': 0.049658387899398804, 'mse': 2.090884087707009e-07}
{'info': {'h': 5, 'w': 128, 'b': 2000.0, 's': 149}, 'pde': 0.0316818542778492, 'bc': 0.04972317814826965, 'mse': 2.114112456918718e-07}
{'info': {'h': 6, 'w': 124, 'b': 1000.0, 's': 123}, 'pde': 0.009747421368956566, 'bc': 0.049698613584041595, 'mse': 2.1468396738527508e-07}
"""


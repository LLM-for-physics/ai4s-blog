# 评估一个网络，计算它的PDE残差、边界残差和与精确解的偏差，以供后续分析

import numpy as np
import torch
from pinn_class import Loss, evaluate as _model_evaluator

def _call(func, x, device='cuda'):
    x = torch.tensor(x, dtype=torch.float32, device=device)
    y = func(x)
    y = y.detach().cpu().numpy()
    return y

def evaluate_model_pde(loss, resolution=32):
    coord = np.linspace(-1, 1, resolution)
    xArr, yArr, zArr=np.meshgrid(coord, coord, coord)
    points=np.stack([xArr, yArr, zArr], axis=-1)
    pde_loss=_call(loss.pde_loss, points, device=loss.model.device)
    return float(pde_loss)

def evaluate_model_bc(loss, resolution=80):
    coord = np.linspace(-1, 1, resolution)
    xArr, yArr, zArr=np.meshgrid(coord, coord, coord)
    points=np.stack([xArr, yArr, zArr], axis=-1)
    bc_loss=_call(loss.boundary_loss, points, device=loss.model.device)
    return float(bc_loss)

with np.load('./results/strict_solution_data.npz') as _file:
    strict_solution_rArr=_file['r']
    strict_solution_oArr=_file['o']

def evaluate_model_mse(model):
    return np.mean((_model_evaluator(model, strict_solution_rArr)-strict_solution_oArr)**2)

def evaluate_model(model):
    model.eval()
    loss=Loss(model, 1, 1)
    return evaluate_model_pde(loss), evaluate_model_bc(loss), evaluate_model_mse(model)


def main():
    from pinn_class import load
    import os
    import json, re

    pattern=re.compile(r'.*?h=(\d+)_w=(\d+)_b=([\d|\.]+)_s=(\d+).*')
    results=[]

    for fp in os.listdir('./results/checkpoints/'):
        if fp.endswith('_best.pth'):
            if(m:=pattern.match(fp)):
                info=dict(
                    h=int(m.groups()[0]), 
                    w=int(m.groups()[1]), 
                    b=float(m.groups()[2]), 
                    s=int(m.groups()[3])
                )
            else:
                continue

            model=load(fp)
            pde_loss, bc_loss, mse_loss=evaluate_model(model)
            results.append(dict(
                info=info, 
                pde=pde_loss, 
                bc=bc_loss, 
                mse=mse_loss
            ))
    with open("./results/loss_result.json", 'w') as file:
        json.dump(results, file)


if __name__ == "__main__":
    main()

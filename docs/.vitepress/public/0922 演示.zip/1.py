import dotenv
import openai
import os

dotenv.load_dotenv('.env')
client = openai.Client(
    api_key=os.getenv("OPENAI_API_KEY"),
    base_url=os.getenv("OPENAI_BASE_URL")
)

def generate(input: list[dict[str, str]]) -> str:
    response = client.chat.completions.create(
        messages=input,
        model="deepseek-v3",
        temperature=0.7,
        top_p=0.95,
        max_tokens=2048,
        stream=True
    )
    result = ""
    for chunk in response:
        if not chunk.choices:
            break
        print(chunk.choices[0].delta.content or "", end="", flush=True)
        result += chunk.choices[0].delta.content or ""
    print()
    return result

import json

def load_prompt(file_path: str) -> list[dict[str, str]]:
    with open(file_path, 'r') as file:
        s = file.read()
        return json.loads(s)


if __name__ == "__main__":
    # print(generate("Explain the theory of relativity in simple terms."))
    messages = load_prompt("prompt/reviewer_answer.json")
    with open("problems/636.md", "r") as f:
        problem = f.read()
    with open("problems/636_answer.md", "r") as f:
        answer = f.read()
    for message in messages:
        message["content"] = message["content"].replace("{problem_statement}", problem).replace("{solution}", answer)
    instruction = "请你检查整个回答过程中是否有数学推导错误、计算错误等等"
    for message in messages:
        message["content"] = message["content"].replace("{instruction}", instruction)
    
    print(generate(messages))

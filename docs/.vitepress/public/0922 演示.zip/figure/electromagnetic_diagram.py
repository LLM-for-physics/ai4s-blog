import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

# Set font for better display
plt.rcParams['font.sans-serif'] = ['DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

def create_electromagnetic_diagram():
    """
    Create electromagnetic diagram for Problem 636:
    - n charged rings distributed along meridional lines
    - negative charge moving in circular motion on equatorial plane
    """
    
    # Parameter settings
    R = 1.0  # sphere radius
    r0 = 3.0  # negative charge orbit radius (r0 >> R)
    n = 6    # number of charged rings
    
    # Create 3D figure
    fig = plt.figure(figsize=(12, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # 1. Draw coordinate axes
    axis_length = r0 * 1.2
    ax.plot([0, axis_length], [0, 0], [0, 0], 'k-', linewidth=2, alpha=0.7)
    ax.plot([0, 0], [0, axis_length], [0, 0], 'k-', linewidth=2, alpha=0.7)
    ax.plot([0, 0], [0, 0], [0, axis_length], 'k-', linewidth=2, alpha=0.7)
    
    # Coordinate axis labels
    ax.text(axis_length, 0, 0, 'X', fontsize=14, fontweight='bold')
    ax.text(0, axis_length, 0, 'Y', fontsize=14, fontweight='bold')
    ax.text(0, 0, axis_length, 'Z', fontsize=14, fontweight='bold')
    ax.text(0, 0, 0, 'O', fontsize=14, fontweight='bold')
    
    # 2. Draw reference sphere (semi-transparent)
    u = np.linspace(0, 2 * np.pi, 30)
    v = np.linspace(0, np.pi, 20)
    x_sphere = R * np.outer(np.cos(u), np.sin(v))
    y_sphere = R * np.outer(np.sin(u), np.sin(v))
    z_sphere = R * np.outer(np.ones(np.size(u)), np.cos(v))
    ax.plot_surface(x_sphere, y_sphere, z_sphere, alpha=0.1, color='lightblue')
    
    # 3. Draw n meridional charged rings
    colors = plt.cm.rainbow(np.linspace(0, 1, n))
    
    for i in range(n):
        # Azimuthal angle for each ring
        phi = i * np.pi / n
        
        # Parametric equations for meridional ring (great circle through poles)
        theta = np.linspace(0, 2*np.pi, 100)
        
        # Ring coordinates
        x_ring = R * np.cos(theta) * np.cos(phi)
        y_ring = R * np.cos(theta) * np.sin(phi)
        z_ring = R * np.sin(theta)
        
        # Draw charged ring
        ax.plot(x_ring, y_ring, z_ring, color=colors[i], linewidth=3, 
                label=f'Ring {i+1} (+Q)')
        
        # Mark positive charge symbols on rings
        mid_idx = len(theta) // 4
        ax.text(x_ring[mid_idx], y_ring[mid_idx], z_ring[mid_idx], 
                '+', fontsize=12, color=colors[i], fontweight='bold')
    
    # 4. Draw negative charge trajectory on equatorial plane
    theta_orbit = np.linspace(0, 2*np.pi, 100)
    x_orbit = r0 * np.cos(theta_orbit)
    y_orbit = r0 * np.sin(theta_orbit)
    z_orbit = np.zeros_like(theta_orbit)
    
    ax.plot(x_orbit, y_orbit, z_orbit, 'r--', linewidth=3, 
            label='Charge trajectory (-q)')
    
    # 5. Draw negative charge position
    charge_pos = [r0, 0, 0]
    ax.scatter(*charge_pos, color='red', s=100, marker='o')
    ax.text(charge_pos[0], charge_pos[1], charge_pos[2] + 0.2, 
            '-q', fontsize=14, color='red', fontweight='bold')
    
    # 6. Draw equatorial plane (semi-transparent disk)
    theta_plane = np.linspace(0, 2*np.pi, 50)
    r_plane = np.linspace(0, r0*1.1, 20)
    THETA, R_PLANE = np.meshgrid(theta_plane, r_plane)
    X_plane = R_PLANE * np.cos(THETA)
    Y_plane = R_PLANE * np.sin(THETA)
    Z_plane = np.zeros_like(X_plane)
    ax.plot_surface(X_plane, Y_plane, Z_plane, alpha=0.1, color='yellow')
    
    # 7. Add pole markers
    ax.scatter([0], [0], [R], color='blue', s=80, marker='^')
    ax.text(0, 0, R+0.2, 'North Pole (0,0,R)', fontsize=10, ha='center')
    ax.scatter([0], [0], [-R], color='blue', s=80, marker='v')
    ax.text(0, 0, -R-0.3, 'South Pole (0,0,-R)', fontsize=10, ha='center')
    
    # 8. Add distance annotation
    ax.plot([0, r0], [0, 0], [0, 0], 'k:', alpha=0.5)
    ax.text(r0/2, 0, 0.2, f'r₀ = {r0}R', fontsize=12, ha='center')
    
    # Set figure properties
    ax.set_xlabel('X', fontsize=12)
    ax.set_ylabel('Y', fontsize=12)
    ax.set_zlabel('Z', fontsize=12)
    ax.set_title('Problem 636: Motion of Negative Charge in Charged Ring System\n'
                f'n={n} charged rings, each with charge +Q, negative charge -q moving in equatorial plane', 
                fontsize=14, pad=20)
    
    # Set coordinate axis ranges
    limit = r0 * 1.2
    ax.set_xlim([-limit, limit])
    ax.set_ylim([-limit, limit])
    ax.set_zlim([-limit, limit])
    
    # Set viewing angle
    ax.view_init(elev=20, azim=45)
    
    # Add legend
    ax.legend(loc='upper left', bbox_to_anchor=(0, 1))
    
    # Add grid
    ax.grid(True, alpha=0.3)
    
    # Add text description
    info_text = (
        f"System Parameters:\n"
        f"• Sphere radius: R\n"
        f"• Number of charged rings: n = {n}\n"
        f"• Angle between adjacent rings: π/n = {np.pi/n:.2f} rad\n"
        f"• Negative charge orbit radius: r₀ >> R\n"
        f"• Charge on each ring: +Q\n"
        f"• Moving charge: -q (mass m)"
    )
    
    plt.figtext(0.02, 0.02, info_text, fontsize=10, 
                bbox=dict(boxstyle="round,pad=0.3", facecolor="lightgray", alpha=0.8))
    
    plt.tight_layout()
    return fig, ax

def create_side_view():
    """Create side view to show ring distribution more clearly"""
    fig, ax = plt.subplots(figsize=(10, 8))
    
    R = 1.0
    r0 = 3.0
    n = 6
    
    # Draw reference circle
    theta = np.linspace(0, 2*np.pi, 100)
    x_circle = R * np.cos(theta)
    z_circle = R * np.sin(theta)
    ax.plot(x_circle, z_circle, 'b--', alpha=0.5, label='Reference sphere')
    
    # Draw meridional rings (shown as ellipses in side view)
    colors = plt.cm.rainbow(np.linspace(0, 1, n))
    for i in range(n):
        phi = i * np.pi / n
        # Projection on xz plane
        x_ring = R * np.cos(theta) * np.cos(phi)
        z_ring = R * np.sin(theta)
        ax.plot(x_ring, z_ring, color=colors[i], linewidth=2, 
                label=f'Ring {i+1} (φ={phi:.2f})')
    
    # Draw equatorial trajectory
    ax.axhline(y=0, xmin=0, xmax=1, color='red', linestyle='--', linewidth=2)
    ax.plot([-r0, r0], [0, 0], 'r-', linewidth=3, label='Charge trajectory')
    ax.scatter([r0], [0], color='red', s=100, marker='o')
    ax.text(r0, 0.2, '-q', fontsize=14, color='red', fontweight='bold')
    
    # Mark poles
    ax.scatter([0], [R], color='blue', s=80, marker='^')
    ax.text(0, R+0.2, 'North Pole', fontsize=10, ha='center')
    ax.scatter([0], [-R], color='blue', s=80, marker='v')
    ax.text(0, -R-0.2, 'South Pole', fontsize=10, ha='center')
    
    ax.set_xlabel('X', fontsize=12)
    ax.set_ylabel('Z', fontsize=12)
    ax.set_title('Side View: Meridional Ring Distribution', fontsize=14)
    ax.grid(True, alpha=0.3)
    ax.legend()
    ax.set_aspect('equal')
    ax.set_xlim([-r0*1.2, r0*1.2])
    ax.set_ylim([-r0*1.2, r0*1.2])
    
    return fig, ax

if __name__ == "__main__":
    # Create 3D diagram
    fig1, ax1 = create_electromagnetic_diagram()
    
    # Create side view
    fig2, ax2 = create_side_view()
    
    # Save figures
    fig1.savefig('electromagnetic_3d_diagram.png', dpi=300, bbox_inches='tight')
    fig2.savefig('electromagnetic_side_view.png', dpi=300, bbox_inches='tight')
    
    # Display figures
    plt.show()
    
    print("Electromagnetic diagrams created successfully!")
    print("- 3D diagram: electromagnetic_3d_diagram.png")
    print("- Side view: electromagnetic_side_view.png")
